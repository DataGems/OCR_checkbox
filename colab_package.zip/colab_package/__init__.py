# Script utilities and entry points
