# Pipeline module for end-to-end checkbox processing
from .pipeline import CheckboxPipeline

__all__ = ["CheckboxPipeline"]
